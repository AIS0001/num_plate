
const { check, validationResult, body } = require('express-validator');
 

module.exports = {
    validate:(body,(req,res,next)=>{
        body.check('name','Name required').required();
       
    
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }
    })
};
